from meapi.me import Me
from meapi._version import __version__
from datetime import date

__copyright__ = f'Copyright {date.today().year} david-lev'
__license__ = 'MIT'
__title__ = 'meapi'
